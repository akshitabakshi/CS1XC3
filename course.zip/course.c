/**
 * @file course.c
 * @author Akshita Bakshi
 * @brief contains definitions for functions involving Course type or Student type or both
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
* enrolls the student in a course
* @param course, a pointer to Course type
* @param student, a pointer to Student type
* @return nothing
**/ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++; //every time a student is enrolled, the total number of students increases
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));// for the first student being enrolled one block of memory is created on the heap
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //the memory block is resized to enroll additional students (more than one)
  }
  course->students[course->total_students - 1] = *student;
}
/**
* prints the details of all students in the course
* @param course, a pointer to Course type
* @return nothing
**/ 
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //iterates over all students in the course to print their details
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
* returns details of the student having the highest average in the course
* @param course, a pointer to Course type
* @return NULL if no students OR pointer to student who has highest average
**/ 
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);// max_average is initialized to the average of the first student
  Student *student = &course->students[0];
  //Checking the averages of students from second student onwards
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) //if avg greater than max, max is reassigned to the current student average
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/**
* returns details of the students who have passed in the given course

* @param course, a pointer to Course type
* @param total_passing, a pointer to int type for storing number of students who passed in given course
* @return dynamic buffer having details of students who have passed in the course
*/ 

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //this loop counts the number of students who have passed
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;//a student passes if their average > = 50
  
  passing = calloc(count, sizeof(Student));//memory block is created of appropriate size to store details of students passing

  int j = 0;
  //stores details of all students who pass to the dynamic array passing
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}