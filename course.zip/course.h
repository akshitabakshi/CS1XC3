/**
 * @file course.h
 * @author Akshita Bakshi
 * @brief defines the Course type and declares the functions using this type
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdbool.h>
 /**

* Course type stores a course with fields name, code, students, total_students
*/ 
typedef struct _course 
{
  char name[100]; /**name of the course*/
  char code[10];/**code of the course*/
  Student *students;/**pointer to the Student type*/
  int total_students;/**total number of students*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


