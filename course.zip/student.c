/**
 * @file student.c
 * @author Akshita
 * @brief contains definitions for functions involving Student type
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**

* Adds grades of the student to the Student type
*
* @param student, a pointer to Student type
* @param grade, grade of the student of type double
* @return nothing
*/ 
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));// for the first grade a memory block of one unit is created on the dynamic array
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);// if more than one grades are to be entered the memory block is resized to accomodate the additional grades of the student
  }
  student->grades[student->num_grades - 1] = grade;
}
/**

* Calculates the average grade of the student
*
* @param student, a pointer to Student type
* @return average grade of student
*/ 

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // adds up the grades of the student and stores it in a variable total
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**

* Prints details of a student : Name, ID, Grades and the Average grade of the student
*
* @param student, a pointer to Student type
* @return nothing
*/ 

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // this loop iterates over grades of the student and prints them
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**

* Generates the details of any random student
*
* @param grades, of integer type
* @return pointer to student who is randomly selected
*/ 
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
  //this loop generates a 10 character id for the student
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';
  //this loop adds a random grade between 25 and 100 for the student 
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}