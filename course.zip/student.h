/**
 * @file student.h
 * @author Akshita Bakshi
 * @brief defines Student type and declares functions involving this type
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**

* Student type stores a student with fields first_name, last_name, id, grades, num_grades
*/ 
typedef struct _student 
{ 
  char first_name[50]; /**first name of the student*/
  char last_name[50];/**last name of the student*/
  char id[11]; /**id of the student*/
  double *grades; /** grades of the student */
  int num_grades; /** number of grades the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
