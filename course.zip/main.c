/**
 * @mainpage Course function demonstration
 * This course function demonstration performs the following,
 * - enrolling students in a course
 * - displaying the details of the top student in the course
 * - displaying the details of students who pass in the course
 * 
 * using two new types created : Student, Course using typedef and struct together
 * @file main.c
 * @author Akshita Bakshi
 * @date 2022-04-08
 * @brief Runs demonstration code involving different functions regarding courses
 * 
 */ 
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));//assigns one block of memory to store this course
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //this loop enrolls 20 randomly generated students into this course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101); //details of the top student are stored in this variable
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing); //to keep track of how many students are passing in this course
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  //iterates over the students who pass in this course and prints their details
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}